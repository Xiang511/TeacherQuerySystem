//====================== RsBean.java =====================
package mybean;
import java.io.*;
import java.sql.*;
public class RsBean
  {
  ResultSet rs = null;
  String rsString = "";
  public RsBean()
    { }
  public void setRs(ResultSet rs)
    {
    this.rs=rs;
    }
  public ResultSet getRs()
    {
    return rs;
    }
  public void setRsString(String rsStr)
    {
    rsString = new String(rsStr);
    }
  public String getRsString() throws Exception
    {
    ResultSetMetaData md = rs.getMetaData();
    int colCount = md.getColumnCount();
    String colLabel[] = new String[colCount + 1];
    StringBuffer sb=new StringBuffer();
    sb.append("<TABLE BORDER=1>");
    sb.append("<TR>");
    for (int i=1; i<=colCount; i++)
      {
      colLabel[i] = md.getColumnLabel(i);
      sb.append("<TD>"+colLabel[i]+"</TD>");
      }
    sb.append("</TR>");
    while (rs.next())
      {
      sb.append("<TR>");
      for (int i=1; i<=colCount; i++)
        {
        String s = (String)rs.getString(i);
        sb.append("<TD>" + s + "</TD>");
        }
      sb.append("</TR>");
      }
    sb.append("</TABLE>");
    return sb.toString();
    }
  }
