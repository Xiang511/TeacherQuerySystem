package bean ; 
public class SayHello {    
    
    public SayHello() {        
    }
    public String SayHello(String strName){
        String strMessage   ;
        strMessage = "Hello " + strName + "  !!  "  ;
        return  strMessage ;
    }    
}
