/*
 * Created on 2004/10/22
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package util.tools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


/**
 * @author hkchang
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SimpleODBCBeanEX {

	private String connectionDriver = "sun.jdbc.odbc.JdbcOdbcDriver";
	private String connectionURL = "jdbc:odbc:COISAT";/*����Ʈw OrderDB*/
	private String userid = "demo";/*����Ʈw user*/
	private String passwd = "demo";/*����Ʈw user*/
	
	private Connection conn ;
	private Statement stat ;
	private ResultSet rs ;
	
	public SimpleODBCBeanEX(String SysDSN){
		this.connectionURL = "jdbc:odbc:" + SysDSN ;
	}
	
	public SimpleODBCBeanEX(){}
	
	
	public Connection getConnectionFromODBC()throws Exception{
		
	 try{
		 // microsoft jdbc �� sourceforge.jtds ��إΪk
		 
		 Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		 conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;database=COISAT",userid,passwd);/*����Ʈw OrderDB*/
		
		 //Class.forName("net.sourceforge.jtds.jdbc.Driver").newInstance() ;
	 	 //conn = DriverManager.getConnection("jdbc:jtds:sqlserver://127.0.0.1:1433",userid,passwd);
	 
	 }catch(ClassNotFoundException cnfe){
	 	System.out.println("[Class for Name Exception] : " + cnfe.toString());
	 }catch(SQLException sqle){
	 	System.out.println("[SQLException] : " + sqle.toString());
	 }
	 	if(conn == null)
	 		throw new Exception("Can't get Connection from ODBC Exception");

	 	return conn ;
	 	
	}
	
	//select 
	public ResultSet doSelect(String selectstr){
		
				
		try{
				
				conn = getConnectionFromODBC();
		
	    		stat = conn.createStatement();
	    		rs = stat.executeQuery(selectstr);
			
		}catch(SQLException sqle){
			sqle.printStackTrace();
	
		}catch(Exception e){
			e.printStackTrace();
		}
			
		//log.debug(this , "Exist doSelect()") ;
		
	    return rs;
	
	}
	
	//add a new record
	public boolean doInsert(String insertstr){
		
		boolean isSuccess = false ;
		try{
		
				conn = getConnectionFromODBC();
			
				stat = conn.createStatement();
				isSuccess = stat.execute(insertstr);
			
		}catch(SQLException sqle){
			sqle.printStackTrace();
		
		}catch(Exception e){
			e.printStackTrace();
		}	
		
			
		return isSuccess ;
	}
	
	//delete record
	public int doDelete(String deletestr){
		
		int counts = 0 ;
		try{
				conn = getConnectionFromODBC();
				
				stat = conn.createStatement();
				counts = stat.executeUpdate(deletestr);
			
		}catch(SQLException sqle){
			sqle.printStackTrace();
		
		}catch(Exception e){
			e.printStackTrace();
		}	
		
		
		return counts ;
	}
	
	//update record
	public int doUpdate(String updatestr){
		
		int counts = 0 ;
		try{
				conn = getConnectionFromODBC();
			
				stat = conn.createStatement();
				counts = stat.executeUpdate(updatestr);
			
		}catch(SQLException sqle){
			sqle.printStackTrace();
		
		}catch(Exception e){
			e.printStackTrace();
		}	
			
		return counts ;
	}
	

	public void close(){
		
		try{
		   if(rs!=null) rs.close();
		   if(stat!=null ) stat.close();
		   if(conn!=null) conn.close();
		}catch(Exception e){
			e.printStackTrace();
		
		}
	
	}
	
	

}
